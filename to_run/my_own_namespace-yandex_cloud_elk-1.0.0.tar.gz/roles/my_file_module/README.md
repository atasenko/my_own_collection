Test my own module
=========

Role for learning module development.

Role Variables
--------------
| vars    | description              |
|---------|--------------------------|
| path    | Filename to create       |
| content | Content for file created |

Example Playbook
----------------

Including an example of how to use your role (for instance, with variables passed in as parameters) is always nice for users too:

    - hosts: servers
      roles:
         - { role: my_file_module }

License
-------

MIT

Author Information
------------------

Aleksei Tasenko